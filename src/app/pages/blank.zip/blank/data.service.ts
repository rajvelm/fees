import {Injectable} from "@angular/core";
import {Http, Response} from '@angular/http';
//import { HttpClient, HttpErrorResponse } from '@angular/http';
//import { HttpClientModule } from '@angular/common/http';
import {Observable} from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import {IData} from './data';
 
 @Injectable()
 export class DataService 
{
     private dataURL = 'http://localhost:4200/assets/data/test.json';
 
     constructor(private _http: Http) {
     }
 
     getData(): Observable<IData[]> {
        return this._http.get(this.dataURL)
            .map((response:Response) => <IData[]>response.json())
    }

    
 }