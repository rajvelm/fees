export interface IData {
    id: string;
    name: string;
    age: string;
    gender: string;
}