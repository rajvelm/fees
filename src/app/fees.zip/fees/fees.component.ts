import { Component, OnInit } from '@angular/core';
import {GridOptions} from "ag-grid";
import {FeesService} from "./fees.service";
import {Fees} from "./fees";

@Component({
  selector: 'app-fees',
  templateUrl: './fees.component.html',
  styleUrls: ['./fees.component.scss'],
  providers:[FeesService]
})
export class FeesComponent implements  OnInit{

  columnDefs: any;
  rowData: any;
  constructor(public fSer: FeesService) {

	this.columnDefs = [
		{
			headerName: "E",
			field: "micCode",
			width: 100
		},
		{
			headerName: "ExchangeName",
			field: "exchangeName",
			width: 100
		},
		{
			headerName: "Desc",
			field: "description",
			width: 100
		},
		{
			headerName: "DateTimeliness",
			field: "dateTimeliness",
			width: 100
		}
    ];
  }

  ngOnInit() {
   this.fSer.getFees().subscribe((data: any) => {
      this.rowData =data;
	  console.log(data);
    });
  }
}

