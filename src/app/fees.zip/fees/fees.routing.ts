import { Routes } from '@angular/router';

import { FeesComponent } from './fees.component';

export const FeesRoutes: Routes = [
	{
	   path: '',
		  component: FeesComponent,
		  data: {
			heading: 'Fees',
			removeFooter: true
		  }
	 } 
];
