/**
 * Created by rm061515 on 4/25/2018.
 */

export class Company {
  /* public connectionId: number;
  public connectionHostId: number;
  public nodeSide: string;
  public role: string;
  public physicalIP: string;
  public externalIP: string;
  public port: number;
  public username: string;
  public updateReason: string; */
  
  public id: number;
  public first_name: string;
  public last_name: string;
  public avatar: string;
}
