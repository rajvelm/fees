/**
 * Created by rm061515 on 4/25/2018.
 */
import { Injectable } from '@angular/core';
// Import Http & Response from angular HTTP module
import { Http, Response, Headers } from '@angular/http';


// Import Observable from rxjs/Observable
import { Observable } from 'rxjs/Observable';
// Import the map operator
import 'rxjs/add/operator/map';

@Injectable()
export class CompanyService {

  private headers: Headers;
  // Inject Angular http service
  constructor(private _http: Http) {

    this.headers = new Headers();
    this.headers.append( 'Content-Type', 'application/json' );
    this.headers.append( 'Accept', 'application/json' );
    this.headers.append('Access-Control-Allow-Origin', '*');


  }

  // Notice the method return type is Observable<IEmployee[]>
  getCompanies(): any {
    // To convert Observable<Response> to Observable<IEmployee[]>
    // we are using the map operator
    var reqObj ={};
    return this._http.get('https://reqres.in/api/users?page=1')
      .map((response: Response) => response.json());
  }
}
